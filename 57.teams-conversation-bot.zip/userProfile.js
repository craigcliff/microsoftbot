class UserProfile {

    constructor(name, email,choiceStep1,choiceStep2,description,contactNumber) {

        

        this.name = name;

        this.email = email;

        this.choiceStep1 = choiceStep1;

        this.name = choiceStep2;

        this.description = description;

        this.contactNumber = contactNumber;

        

    }

}


 

module.exports.UserProfile = UserProfile;